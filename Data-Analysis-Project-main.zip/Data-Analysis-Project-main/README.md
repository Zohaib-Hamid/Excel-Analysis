# Data-Analysis-Project

In this project I took an Excel Sheet where Annual Store Data was collected and then I checked for duplications and null values in the data then add some cells for more esay understandind of the sales and purchases.
after filtering and processing the data I used charts for showing the required data from the client and add slicers for more convenient.
